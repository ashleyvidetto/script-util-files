========================================================================
tasky Project Overview
========================================================================

Description:
------------
This project provides a plug-in which allows Launchy to search window titles of currently open windows giving users a convenient way to switch between tasks. Supports Launchy 2.0 only.

Changelog:
----------
0.2b
- Added catalog item Tasky. Type Tasky and press TAB button to see all tasks.
Type Tasky and press Enter button to redo the last task switch.

Website:
--------
http://tasky-launchy.sourceforge.net/

Installation:
-------------
Copy tasky.dll to <Launchy install dir>\plugins, copy tasky.png to <Launchy install dir>\plugins\icons and restart Launchy.

/////////////////////////////////////////////////////////////////////////////
